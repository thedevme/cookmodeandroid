# CookMode Android — Build Plan v1

A sequential execution checklist optimized for **fast launch**.

**Philosophy:** Cooking Mode is the product. Ship that first, polish everything else around it.

---

## Quick Reference: All Milestones

| Step | Milestone |
|------|-----------|
| 35 | ✓ Models + Database Working |
| 55 | ✓ Cooking Mode Functional |
| 75 | ✓ Full Recipe CRUD |
| 90 | ✓ Timers Work (Background) |
| **105** | **🚀 ALPHA — Internal Testing** |
| **135** | **🚀 BETA — Monetization Working** |
| **165** | **🎉 LAUNCH** |

---

## Timeline

| Build | Target | Step | What's Working |
|-------|--------|------|----------------|
| **Alpha** | End of Week 1 | 105 | Add recipes, Cooking Mode, timers, basic UI |
| **Beta** | End of Week 2 | 135 | Pro unlock, paywall, polish |
| **Launch** | Week 2-3 | 165 | Play Store release |

---

## Project Configuration

**Package ID:** `io.designtoswiftui.cookmode`
**Developer:** Cocoa Academy

---

## Phase 1: Project Setup

### 1.1 — Create Android Studio Project
- [ ] 1. Create new project: "CookMode" (Empty Activity with Jetpack Compose)
- [ ] 2. Set minimum SDK to API 24
- [ ] 3. Set Kotlin DSL for build configuration
- [ ] 4. Set screen orientation to Portrait only
- [ ] 5. Set app theme to dark only

### 1.2 — Configure Project Structure
- [ ] 6. Create package: `models/`
- [ ] 7. Create package: `data/`
- [ ] 8. Create package: `data/repository/`
- [ ] 9. Create package: `ui/`
- [ ] 10. Create package: `ui/home/`
- [ ] 11. Create package: `ui/recipe/`
- [ ] 12. Create package: `ui/cooking/`
- [ ] 13. Create package: `ui/paywall/`
- [ ] 14. Create package: `ui/components/`
- [ ] 15. Create package: `viewmodels/`
- [ ] 16. Create package: `timer/`
- [ ] 17. Create package: `util/`

### 1.3 — Configuration Files
- [ ] 18. Update `.gitignore`
- [ ] 19. Create `README.md`
- [ ] 20. Create `CLAUDE.md`
- [ ] 21. Create `/docs` folder with specs

---

## Phase 2: Data Models

### 2.1 — Create Core Models
- [ ] 22. Create `models/Recipe.kt`
  - @Entity: id, title, imageUri, prepTime, servings, createdAt

- [ ] 23. Create `models/Ingredient.kt`
  - @Entity: id, recipeId (FK), amount, unit, name, orderIndex

- [ ] 24. Create `models/Step.kt`
  - @Entity: id, recipeId (FK), instruction, timerSeconds (nullable), orderIndex

- [ ] 25. Create `models/RecipeWithDetails.kt`
  - Data class combining Recipe + List<Ingredient> + List<Step>

### 2.2 — Configure Room
- [ ] 26. Add Room dependencies to build.gradle.kts
- [ ] 27. Create `data/AppDatabase.kt`
- [ ] 28. Create `data/RecipeDao.kt`
- [ ] 29. Create `data/IngredientDao.kt`
- [ ] 30. Create `data/StepDao.kt`
- [ ] 31. Configure Hilt + DatabaseModule

### 2.3 — Repository
- [ ] 32. Create `data/repository/RecipeRepository.kt`
- [ ] 33. Implement `suspend fun saveRecipe(recipe, ingredients, steps)`
- [ ] 34. Implement `fun getAllRecipes(): Flow<List<Recipe>>`
- [ ] 35. Implement `suspend fun getRecipeWithDetails(id): RecipeWithDetails`
- [ ] 36. Implement `suspend fun deleteRecipe(id)`
- [ ] 37. Implement `fun getRecipeCount(): Flow<Int>`

**✅ MILESTONE: Models + Database Working (Step 35)**

---

## Phase 3: Cooking Mode (Core Feature)

### 3.1 — Cooking State
- [ ] 38. Create `ui/cooking/CookingState.kt`
  - currentStepIndex, steps, isTimerRunning, timerSecondsRemaining

- [ ] 39. Create `viewmodels/CookingViewModel.kt`
- [ ] 40. Implement `fun loadRecipe(recipeId)`
- [ ] 41. Implement `fun nextStep()`
- [ ] 42. Implement `fun previousStep()`
- [ ] 43. Implement `fun startTimer()`
- [ ] 44. Implement `fun pauseTimer()`
- [ ] 45. Implement `fun resetTimer()`

### 3.2 — Cooking Mode UI
- [ ] 46. Create `ui/cooking/CookingScreen.kt`
- [ ] 47. Step progress indicator ("2 of 6")
- [ ] 48. Large step instruction text (centered)
- [ ] 49. Timer display (MM:SS) when step has timer
- [ ] 50. Play/Pause timer button
- [ ] 51. Back / Next Step buttons
- [ ] 52. Keep screen on (FLAG_KEEP_SCREEN_ON)
- [ ] 53. Exit button (X) with confirmation
- [ ] 54. Step list drawer (tap icon to see all steps)
- [ ] 55. Step transition animations

**✅ MILESTONE: Cooking Mode Functional (Step 55)**

---

## Phase 4: Recipe Management

### 4.1 — Home Screen
- [ ] 56. Create `viewmodels/HomeViewModel.kt`
- [ ] 57. StateFlow: recipes, searchQuery
- [ ] 58. Create `ui/home/HomeScreen.kt`
- [ ] 59. Recipe list (LazyColumn)
- [ ] 60. Each item: icon, title, prep time, chevron
- [ ] 61. Search bar
- [ ] 62. FAB to add recipe
- [ ] 63. Empty state ("Add your first recipe")

### 4.2 — Add/Edit Recipe Screen
- [ ] 64. Create `viewmodels/EditRecipeViewModel.kt`
- [ ] 65. Create `ui/recipe/EditRecipeScreen.kt`
- [ ] 66. Image picker (optional photo)
- [ ] 67. Title field
- [ ] 68. Prep time field
- [ ] 69. Servings field
- [ ] 70. Ingredients section (add/remove/reorder)
- [ ] 71. Steps section (add/remove/reorder)
- [ ] 72. Timer toggle per step (with duration picker)
- [ ] 73. Save button
- [ ] 74. Validation (title + at least 1 step required)
- [ ] 75. Delete recipe option (edit mode only)

**✅ MILESTONE: Full Recipe CRUD (Step 75)**

---

## Phase 5: Timer Service

### 5.1 — Background Timer
- [ ] 76. Create `timer/TimerService.kt` (Foreground Service)
- [ ] 77. Create notification channel
- [ ] 78. Show ongoing notification with time remaining
- [ ] 79. Handle timer completion notification (sound + vibrate)
- [ ] 80. Bind service to CookingViewModel

### 5.2 — Timer Polish
- [ ] 81. Timer continues when app backgrounded
- [ ] 82. Timer continues when screen locked
- [ ] 83. Tapping notification returns to Cooking Mode
- [ ] 84. Multiple sequential timers work correctly
- [ ] 85. Timer alarm sound selection (default system)

### 5.3 — Permissions
- [ ] 86. Request notification permission (Android 13+)
- [ ] 87. Request POST_NOTIFICATIONS gracefully
- [ ] 88. Handle permission denied state
- [ ] 89. Add foreground service permission to manifest
- [ ] 90. Test on Android 13+ and older

**✅ MILESTONE: Timers Work (Step 90)**

---

## Phase 6: Navigation + Polish

### 6.1 — Navigation
- [ ] 91. Add Navigation Compose dependency
- [ ] 92. Create `ui/navigation/NavGraph.kt`
- [ ] 93. Routes: Home, EditRecipe, Cooking
- [ ] 94. Home → tap recipe → Cooking Mode
- [ ] 95. Home → FAB → EditRecipe (new)
- [ ] 96. Home → long press recipe → EditRecipe (edit)
- [ ] 97. Cooking → X → Home (with confirmation)

### 6.2 — UI Polish
- [ ] 98. Recipe icons/emojis (auto-assign or pick)
- [ ] 99. Swipe to delete on home screen
- [ ] 100. Pull to refresh (not needed but feels nice)
- [ ] 101. Loading states
- [ ] 102. Error states
- [ ] 103. Haptic feedback on timer complete
- [ ] 104. Step transition animations
- [ ] 105. Test full flow end-to-end

**✅ 🚀 ALPHA — Internal Testing (Step 105)**

---

## Phase 7: Monetization

### 7.1 — Premium Manager
- [ ] 106. Create `data/PremiumManager.kt`
- [ ] 107. Store purchase state in DataStore
- [ ] 108. Implement `isPremium: StateFlow<Boolean>`
- [ ] 109. Implement `fun unlock()`

### 7.2 — Free Tier Limits
- [ ] 110. Check recipe count before adding (limit: 5)
- [ ] 111. Show upgrade prompt when limit reached
- [ ] 112. Free tier still gets full Cooking Mode

### 7.3 — Paywall Screen
- [ ] 113. Create `ui/paywall/PaywallScreen.kt`
- [ ] 114. Hero image
- [ ] 115. Feature list (unlimited recipes, scaling, etc.)
- [ ] 116. Price display ($4.99 one-time)
- [ ] 117. Purchase button
- [ ] 118. Restore purchases link

### 7.4 — Google Play Billing
- [ ] 119. Add Play Billing library
- [ ] 120. Create `data/BillingManager.kt`
- [ ] 121. Query product details
- [ ] 122. Launch purchase flow
- [ ] 123. Handle purchase success
- [ ] 124. Handle purchase failure
- [ ] 125. Verify purchase on app start
- [ ] 126. Restore purchases flow

### 7.5 — Pro Features
- [ ] 127. Ingredient scaling UI (½×, 1×, 2×, custom)
- [ ] 128. Scaling logic in CookingViewModel
- [ ] 129. Gate scaling behind premium check
- [ ] 130. "Import from clipboard" button (basic text parsing)
- [ ] 131. Gate import behind premium check

### 7.6 — Beta Prep
- [ ] 132. Test purchase flow with test cards
- [ ] 133. Test restore flow
- [ ] 134. Test free tier limits
- [ ] 135. Upload to closed testing track

**✅ 🚀 BETA — Monetization Working (Step 135)**

---

## Phase 8: Launch Prep

### 8.1 — Polish
- [ ] 136. Review all screens match design
- [ ] 137. Test on multiple screen sizes
- [ ] 138. Test on Android 8, 10, 12, 14
- [ ] 139. Fix any crashes
- [ ] 140. Add analytics (Firebase)
- [ ] 141. Add crash reporting (Crashlytics)

### 8.2 — Accessibility
- [ ] 142. Content descriptions on all buttons
- [ ] 143. Test with TalkBack
- [ ] 144. Test with large font sizes
- [ ] 145. Ensure timer alerts work with accessibility

### 8.3 — Store Assets
- [ ] 146. App icon (512x512)
- [ ] 147. Feature graphic (1024x500)
- [ ] 148. Screenshots (phone) — at least 4
- [ ] 149. Short description (80 chars)
- [ ] 150. Full description
- [ ] 151. Privacy policy URL
- [ ] 152. Create promo video (optional)

### 8.4 — Play Store Submission
- [ ] 153. Complete store listing
- [ ] 154. Set up pricing (free with IAP)
- [ ] 155. Configure in-app product ($4.99)
- [ ] 156. Content rating questionnaire
- [ ] 157. Data safety form
- [ ] 158. Target audience declaration
- [ ] 159. Upload release AAB
- [ ] 160. Submit for review
- [ ] 161. Address any review feedback
- [ ] 162. Release to production
- [ ] 163. Announce launch
- [ ] 164. Monitor reviews + crashes
- [ ] 165. Plan v1.1 based on feedback

**✅ 🎉 LAUNCH (Step 165)**

---

## Summary

| Week | Goal | Steps | Release |
|------|------|-------|---------|
| 1 | Core + Cooking Mode | 1-105 | Alpha |
| 2 | Monetization + Polish | 106-135 | Beta |
| 2-3 | Launch | 136-165 | Production |

**Total: 165 steps**

---

## Key Dependencies

```kotlin
dependencies {
    // Compose
    implementation(platform("androidx.compose:compose-bom:2024.01.00"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.activity:activity-compose")
    implementation("androidx.navigation:navigation-compose")
    
    // Room
    implementation("androidx.room:room-runtime:2.6.1")
    implementation("androidx.room:room-ktx:2.6.1")
    ksp("androidx.room:room-compiler:2.6.1")
    
    // Hilt
    implementation("com.google.dagger:hilt-android:2.50")
    ksp("com.google.dagger:hilt-compiler:2.50")
    implementation("androidx.hilt:hilt-navigation-compose:1.1.0")
    
    // DataStore
    implementation("androidx.datastore:datastore-preferences:1.0.0")
    
    // Billing
    implementation("com.android.billingclient:billing-ktx:6.1.0")
    
    // Images
    implementation("io.coil-kt:coil-compose:2.5.0")
    
    // Firebase (optional)
    implementation(platform("com.google.firebase:firebase-bom:32.7.0"))
    implementation("com.google.firebase:firebase-analytics-ktx")
    implementation("com.google.firebase:firebase-crashlytics-ktx")
}
```

---

## Post-Launch Features (v1.1+)

- Voice control ("next step", "start timer")
- Import from URL (parse recipe websites)
- Tablet / landscape Cooking Mode
- Wear OS timer companion
- Widget showing active timer
- Recipe sharing (export to text/PDF)
- Collections / folders
- Cloud sync (requires backend)
